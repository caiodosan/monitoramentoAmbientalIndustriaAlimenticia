package fiap.heinzChallenge;

public class Produto {

  private String codProduto;
  private String nomeProduto;
  private String descricao;
  private String codLote;
  private int codDistribuicao;

  public Produto(
    String codProduto,
    String nomeProduto,
    String descricao,
    String codLote,
    int codDistribuicao
  ) {
    this.codProduto = codProduto;
    this.nomeProduto = nomeProduto;
    this.descricao = descricao;
    this.codLote = codLote;
    this.codDistribuicao = codDistribuicao;
  }

  public String getCodProduto() {
    return codProduto;
  }

  public void setCodProduto(String codProduto) {
    this.codProduto = codProduto;
  }

  public String getNomeProduto() {
    return nomeProduto;
  }

  public void setNomeProduto(String nomeProduto) {
    this.nomeProduto = nomeProduto;
  }

  public String getDescricao() {
    return descricao;
  }

  public void setDescricao(String descricao) {
    this.descricao = descricao;
  }

  public String getCodLote() {
    return codLote;
  }

  public void setCodLote(String codLote) {
    this.codLote = codLote;
  }

  public int getCodDistribuicao() {
    return codDistribuicao;
  }

  public void setCodDistribuicao(int codDistribuicao) {
    this.codDistribuicao = codDistribuicao;
  }
}
