package fiap.heinzChallenge;

public class MateriaPrima {

  private String codMateriaPrima;
  private String nomeMateriaPrima;
  private String descricao;
  private String codLote;
  private int codDistribuicao;

  public MateriaPrima(
    String codMateriaPrima,
    String nomeMateriaPrima,
    String descricao,
    String codLote,
    int codDistribuicao
  ) {
    this.codMateriaPrima = codMateriaPrima;
    this.nomeMateriaPrima = nomeMateriaPrima;
    this.descricao = descricao;
    this.codLote = codLote;
    this.codDistribuicao = codDistribuicao;
  }

  public String getCodMateriaPrima() {
    return codMateriaPrima;
  }

  public void setCodMateriaPrima(String codMateriaPrima) {
    this.codMateriaPrima = codMateriaPrima;
  }

  public String getNomeMateriaPrima() {
    return nomeMateriaPrima;
  }

  public void setNomeMateriaPrima(String nomeMateriaPrima) {
    this.nomeMateriaPrima = nomeMateriaPrima;
  }

  public String getDescricao() {
    return descricao;
  }

  public void setDescricao(String descricao) {
    this.descricao = descricao;
  }

  public String getCodLote() {
    return codLote;
  }

  public void setCodLote(String codLote) {
    this.codLote = codLote;
  }

  public int getCodDistribuicao() {
    return codDistribuicao;
  }

  public void setCodDistribuicao(int codDistribuicao) {
    this.codDistribuicao = codDistribuicao;
  }
}
