package fiap.heinzChallenge;

import java.sql.Date;

public class Lote {

  private String codLote;
  private Date dataFabricacao;
  private Date dataValidade;
  private double pesoLote;
  private int codDistribuicao;

  public Lote(
    String codLote,
    Date dataFabricacao,
    Date dataValidade,
    double pesoLote,
    int codDistribuicao
  ) {
    this.codLote = codLote;
    this.dataFabricacao = dataFabricacao;
    this.dataValidade = dataValidade;
    this.pesoLote = pesoLote;
    this.codDistribuicao = codDistribuicao;
  }

  public String getCodLote() {
    return codLote;
  }

  public void setCodLote(String codLote) {
    this.codLote = codLote;
  }

  public Date getDataFabricacao() {
    return dataFabricacao;
  }

  public void setDataFabricacao(Date dataFabricacao) {
    this.dataFabricacao = dataFabricacao;
  }

  public Date getDataValidade() {
    return dataValidade;
  }

  public void setDataValidade(Date dataValidade) {
    this.dataValidade = dataValidade;
  }

  public double getPesoLote() {
    return pesoLote;
  }

  public void setPesoLote(double pesoLote) {
    this.pesoLote = pesoLote;
  }

  public int getCodDistribuicao() {
    return codDistribuicao;
  }

  public void setCodDistribuicao(int codDistribuicao) {
    this.codDistribuicao = codDistribuicao;
  }
}
