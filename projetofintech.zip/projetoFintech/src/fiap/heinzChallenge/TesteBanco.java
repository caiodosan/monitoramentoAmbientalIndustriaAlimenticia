package fiap.heinzChallenge;

import fiap.heinzChallenge.dao.OracleDistribuicaoDAO;
import fiap.heinzChallenge.dao.OracleLoteDAO;
import fiap.heinzChallenge.dao.OracleMateriaPrimaDAO;
import fiap.heinzChallenge.dao.OracleMonitoramentoDAO;
import fiap.heinzChallenge.dao.OracleProducaoDAO;
import fiap.heinzChallenge.dao.OracleProdutoDAO;
import fiap.heinzChallenge.dao.factory.DAOFactory;
import fiap.heinzChallenge.dao.models.DistribuicaoDAO;
import fiap.heinzChallenge.dao.models.LoteDAO;
import fiap.heinzChallenge.dao.models.MateriaPrimaDAO;
import fiap.heinzChallenge.dao.models.MonitoramentoDAO;
import fiap.heinzChallenge.dao.models.ProducaoDAO;
import fiap.heinzChallenge.dao.models.ProdutoDAO;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.List;
import java.sql.Timestamp;

public class TesteBanco {

  private static final Connection conexao = ConnectionManager.obterConexao();

  public static void main(String[] args) {
    try {
      manipulaDistribuicao();
      manipulaLote();
      manipulaProduto();
      manipulaMonitoramento();
      manipulaMateriaPrima();
      manipulaProducao();
      conexao.close();
    } catch (SQLException e) {
      System.err.println("Não foi possível conectar no banco de dados Oracle");
      e.printStackTrace();
    }
  }

  public static void manipulaProduto() {
    ProdutoDAO dao = new OracleProdutoDAO();

    Produto produto = new Produto(
      "1",
      "Produto 1",
      "Descrição do Produto 1",
      "1",
      1
    );
    dao.cadastrar(produto);

  }

  public static void manipulaDistribuicao() {
	Date data = new Date(0);
    DistribuicaoDAO dao = new OracleDistribuicaoDAO();

    Distribuicao distribuicao = new Distribuicao(
      1,
      10,
      1,
      data
      
    );
    dao.cadastrar(distribuicao);


  }

  public static void manipulaLote() {
    LoteDAO dao = new OracleLoteDAO();
    Date dataini = new Date(0);
    Date datafim = new Date(05);

    Lote lote = new Lote("1", dataini, datafim,100, 1);
    dao.cadastrar(lote);


    //dao.remover("L001", "M001");
  }

  public static void manipulaMateriaPrima() {
    MateriaPrimaDAO dao = new OracleMateriaPrimaDAO();

    MateriaPrima materiaPrima = new MateriaPrima(
      "1",
      "tomate",
      "tomate para ketchup",
      "1",
      1
    );
    dao.cadastrar(materiaPrima);
    //dao.remover("M001");
  }
  
  

  public static void manipulaMonitoramento() {
	  
    MonitoramentoDAO dao = new OracleMonitoramentoDAO();
    Date monitora = new Date(0);

    Monitoramento monitoramento = new Monitoramento(
      "1",
      "agua",
      "agua do ketchup",
      monitora,
      100,
      "litros",
      "1",
       1
    );
    dao.cadastrar(monitoramento);

    //dao.remover("M001");
  }

  public static void manipulaProducao() {
    ProducaoDAO dao = new OracleProducaoDAO();
    
    Timestamp dataini = new Timestamp(0);
    Timestamp datafim = new Timestamp(0);

    Producao producao = new Producao("1",dataini,datafim, "1", 1);
    dao.cadastrar(producao);

  }
}
