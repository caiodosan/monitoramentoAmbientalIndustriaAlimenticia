package fiap.heinzChallenge;

import java.sql.Timestamp;

public class Producao {

  private String codProducao;
  private Timestamp dtInicio;
  private Timestamp dtFim;
  private String codLote;
  private int codDistribuicao;

  public Producao(
    String codProducao,
    Timestamp dtInicio,
    Timestamp dtFim,
    String codLote,
    int codDistribuicao
  ) {
    this.codProducao = codProducao;
    this.dtInicio = dtInicio;
    this.dtFim = dtFim;
    this.codLote = codLote;
    this.codDistribuicao = codDistribuicao;
  }

  public String getCodProducao() {
    return codProducao;
  }

  public void setCodProducao(String codProducao) {
    this.codProducao = codProducao;
  }

  public Timestamp getDtInicio() {
    return dtInicio;
  }

  public void setDtInicio(Timestamp dtInicio) {
    this.dtInicio = dtInicio;
  }

  public Timestamp getDtFim() {
    return dtFim;
  }

  public void setDtFim(Timestamp dtFim) {
    this.dtFim = dtFim;
  }

  public String getCodLote() {
    return codLote;
  }

  public void setCodLote(String codLote) {
    this.codLote = codLote;
  }

  public int getCodDistribuicao() {
    return codDistribuicao;
  }

  public void setCodDistribuicao(int codDistribuicao) {
    this.codDistribuicao = codDistribuicao;
  }
}
