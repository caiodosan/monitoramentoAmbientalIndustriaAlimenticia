package fiap.heinzChallenge;

import java.sql.Date;

public class Monitoramento {

  private String codMonitoramento;
  private String tipo;
  private String descricao;
  private Date data;
  private double valor;
  private String unidadeMedida;
  private String codLote;
  private int codDistribuicao;

  public Monitoramento(
    String codMonitoramento,
    String tipo,
    String descricao,
    Date data,
    double valor,
    String unidadeMedida,
    String codLote,
    int codDistribuicao
  ) {
    this.codMonitoramento = codMonitoramento;
    this.tipo = tipo;
    this.descricao = descricao;
    this.data = data;
    this.valor = valor;
    this.unidadeMedida = unidadeMedida;
    this.codLote = codLote;
    this.codDistribuicao = codDistribuicao;
  }

  public String getCodMonitoramento() {
    return codMonitoramento;
  }

  public void setCodMonitoramento(String codMonitoramento) {
    this.codMonitoramento = codMonitoramento;
  }

  public String getTipo() {
    return tipo;
  }

  public void setTipo(String tipo) {
    this.tipo = tipo;
  }

  public String getDescricao() {
    return descricao;
  }

  public void setDescricao(String descricao) {
    this.descricao = descricao;
  }

  public Date getData() {
    return data;
  }

  public void setData(Date data) {
    this.data = data;
  }

  public double getValor() {
    return valor;
  }

  public void setValor(double valor) {
    this.valor = valor;
  }

  public String getUnidadeMedida() {
    return unidadeMedida;
  }

  public void setUnidadeMedida(String unidadeMedida) {
    this.unidadeMedida = unidadeMedida;
  }

  public String getCodLote() {
    return codLote;
  }

  public void setCodLote(String codLote) {
    this.codLote = codLote;
  }

  public int getCodDistribuicao() {
    return codDistribuicao;
  }

  public void setCodDistribuicao(int codDistribuicao) {
    this.codDistribuicao = codDistribuicao;
  }
}
