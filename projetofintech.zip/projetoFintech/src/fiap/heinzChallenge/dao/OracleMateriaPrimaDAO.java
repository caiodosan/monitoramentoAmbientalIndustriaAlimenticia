package fiap.heinzChallenge.dao;

import fiap.heinzChallenge.ConnectionManager;
import fiap.heinzChallenge.MateriaPrima;
import fiap.heinzChallenge.dao.models.MateriaPrimaDAO;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OracleMateriaPrimaDAO implements MateriaPrimaDAO {

  private Connection connection;

  public OracleMateriaPrimaDAO() {
    this.connection = ConnectionManager.obterConexao();
  }

  @Override
  public void cadastrar(MateriaPrima materiaPrima) {
    String sql =
      "INSERT INTO T_MATERIA_PRIMA (cod_materia_prima, nm_materia_prima, ds_descricao, T_LOTE_COD_LOTE ,T_LOTE_T_DISTRIBUICAO_COD_DISTRIBUICAO) VALUES (?, ?, ?, ?,?)";

    try (PreparedStatement stmt = connection.prepareStatement(sql)) {
      stmt.setString(1, materiaPrima.getCodMateriaPrima());
      stmt.setString(2, materiaPrima.getNomeMateriaPrima());
      stmt.setString(3, materiaPrima.getDescricao());
      stmt.setString(4, materiaPrima.getCodLote());
      stmt.setInt(5, materiaPrima.getCodDistribuicao());
      stmt.executeUpdate();
    } catch (SQLException e) {
      throw new RuntimeException(e);
    }
  }

  @Override
  public List<MateriaPrima> listar() {
    System.out.println("Listando matérias-primas do banco de dados Oracle");
    return null;
  }

  @Override
  public void atualizar(MateriaPrima materiaPrima) {
    System.out.println(
      "Matéria-prima atualizada no banco de dados Oracle: " + materiaPrima
    );
  }


@Override
public void remover(String codMateriaPrima, String codLote, int codDistribuicao) {
	// TODO Auto-generated method stub
	
}

@Override
public MateriaPrima buscarPorId(String codMateriaPrima, String codLote, int codDistribuicao) {
	// TODO Auto-generated method stub
	return null;
}
}
