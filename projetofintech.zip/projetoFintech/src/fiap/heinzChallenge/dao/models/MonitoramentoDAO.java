package fiap.heinzChallenge.dao.models;

import fiap.heinzChallenge.Monitoramento;
import java.util.List;

public interface MonitoramentoDAO {
  public void cadastrar(Monitoramento monitoramento);

  public List<Monitoramento> listar();

  public void atualizar(Monitoramento monitoramento);

  public void remover(String codMonitoramento);

  public Monitoramento buscarPorId(String codMonitoramento);
}
