package fiap.heinzChallenge.dao.models;

import fiap.heinzChallenge.MateriaPrima;
import java.util.List;

public interface MateriaPrimaDAO {
  public void cadastrar(MateriaPrima materiaPrima);

  public List<MateriaPrima> listar();

  public void atualizar(MateriaPrima materiaPrima);

  public void remover(
    String codMateriaPrima,
    String codLote,
    int codDistribuicao
  );

  public MateriaPrima buscarPorId(
    String codMateriaPrima,
    String codLote,
    int codDistribuicao
  );
}
