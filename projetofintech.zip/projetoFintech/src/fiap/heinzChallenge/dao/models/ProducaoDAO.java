package fiap.heinzChallenge.dao.models;

import fiap.heinzChallenge.Producao;

import java.util.List;

public interface ProducaoDAO {
  public void cadastrar(Producao producao);

  public List<Producao> listar();

  public void atualizar(Producao producao);

  public void remover(String codProducao);

  public Producao buscarPorId(String codProducao);
}
