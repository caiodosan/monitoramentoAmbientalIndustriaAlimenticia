package fiap.heinzChallenge.dao.models;

import fiap.heinzChallenge.Lote;
import java.util.List;

public interface LoteDAO {
  public void cadastrar(Lote lote);

  public List<Lote> listar();

  public void atualizar(Lote lote);

  public void remover(String codLote, int codDistribuicao);

  public Lote buscarPorId(String codLote, int codDistribuicao);
}
