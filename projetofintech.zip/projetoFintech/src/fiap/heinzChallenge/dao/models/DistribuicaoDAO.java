package fiap.heinzChallenge.dao.models;

import fiap.heinzChallenge.Distribuicao;
import java.util.List;

public interface DistribuicaoDAO {
  public void cadastrar(Distribuicao distribuicao);

  public List<Distribuicao> listar();

  public void atualizar(Distribuicao distribuicao);

  public void remover(int codigo);

  public Distribuicao buscarPorId(int codigoBusca);
}
