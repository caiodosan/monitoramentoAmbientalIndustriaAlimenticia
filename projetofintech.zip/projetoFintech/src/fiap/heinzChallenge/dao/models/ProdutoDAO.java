package fiap.heinzChallenge.dao.models;

import fiap.heinzChallenge.Produto;
import java.util.List;

public interface ProdutoDAO {
  public void cadastrar(Produto produto);

  public List<Produto> listar();

  public void atualizar(Produto produto);

  public void remover(String codProduto, String codLote, int codDistribuicao);

  public Produto buscarPorId(
    String codProduto,
    String codLote,
    int codDistribuicao
  );
  
}
