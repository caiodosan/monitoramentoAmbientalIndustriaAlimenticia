package fiap.heinzChallenge.dao;

import fiap.heinzChallenge.ConnectionManager;
import fiap.heinzChallenge.Produto;
import fiap.heinzChallenge.dao.models.ProdutoDAO;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OracleProdutoDAO implements ProdutoDAO {

  private Connection connection;

  public OracleProdutoDAO() {
    this.connection = ConnectionManager.obterConexao();
  }

  @Override
  public void cadastrar(Produto produto) {
    String sql =
      "INSERT INTO T_PRODUTO (cod_produto, nm_produto, ds_descricao, T_LOTE_COD_LOTE, T_LOTE_T_DISTRIBUICAO_COD_DISTRIBUICAO) VALUES (?, ?, ?, ?, ?)";

    try (PreparedStatement stmt = connection.prepareStatement(sql)) {
      stmt.setString(1, produto.getCodProduto());
      stmt.setString(2, produto.getNomeProduto());
      stmt.setString(3, produto.getDescricao());
      stmt.setString(4, produto.getCodLote());
      stmt.setInt(5, produto.getCodDistribuicao());
      stmt.executeUpdate();
    } catch (SQLException e) {
      throw new RuntimeException(e);
    }
  }

  @Override
  public List<Produto> listar() {
    System.out.println("Listando produtos do banco de dados Oracle");
    return null;
  }

  @Override
  public void atualizar(Produto produto) {
    System.out.println(
      "Produto atualizado no banco de dados Oracle: " + produto
    );
  }

  @Override
  public void remover(String codProduto, String codLote, int codDistribuicao) {
    System.out.println(
      "Produto removido do banco de dados Oracle. Código do Produto: " +
      codProduto +
      ", Código do Lote: " +
      codLote +
      ", Código da Distribuição: " +
      codDistribuicao
    );
  }

  @Override
  public Produto buscarPorId(
    String codProduto,
    String codLote,
    int codDistribuicao
  ) {
    System.out.println(
      "Buscando produto no banco de dados Oracle. Código do Produto: " +
      codProduto +
      ", Código do Lote: " +
      codLote +
      ", Código da Distribuição: " +
      codDistribuicao
    );
    return null;
  }
}
