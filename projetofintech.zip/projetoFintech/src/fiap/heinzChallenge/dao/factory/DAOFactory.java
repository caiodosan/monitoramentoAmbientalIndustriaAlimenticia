package fiap.heinzChallenge.dao.factory;

import fiap.heinzChallenge.dao.OracleDistribuicaoDAO;
import fiap.heinzChallenge.dao.OracleLoteDAO;
import fiap.heinzChallenge.dao.OracleMateriaPrimaDAO;
import fiap.heinzChallenge.dao.OracleMonitoramentoDAO;
import fiap.heinzChallenge.dao.OracleProducaoDAO;
import fiap.heinzChallenge.dao.OracleProdutoDAO;
import fiap.heinzChallenge.dao.models.DistribuicaoDAO;
import fiap.heinzChallenge.dao.models.LoteDAO;
import fiap.heinzChallenge.dao.models.MateriaPrimaDAO;
import fiap.heinzChallenge.dao.models.MonitoramentoDAO;
import fiap.heinzChallenge.dao.models.ProducaoDAO;
import fiap.heinzChallenge.dao.models.ProdutoDAO;

public abstract class DAOFactory {

  public static ProdutoDAO getProdutoDAO() {
    return new OracleProdutoDAO();
  }

  public static DistribuicaoDAO getDistribuicaoDAO() {
    return new OracleDistribuicaoDAO();
  }

  public static LoteDAO getLoteDAO() {
    return new OracleLoteDAO();
  }

  public static MonitoramentoDAO getMonitoramentoDAO() {
    return new OracleMonitoramentoDAO();
  }

  public static MateriaPrimaDAO getMateriaPrimaDAO() {
    return new OracleMateriaPrimaDAO();
  }

  public static ProducaoDAO getProducaoDAO() {
    return new OracleProducaoDAO();
  }
}
