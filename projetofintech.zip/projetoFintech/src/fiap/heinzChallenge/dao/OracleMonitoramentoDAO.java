package fiap.heinzChallenge.dao;

import fiap.heinzChallenge.ConnectionManager;
import fiap.heinzChallenge.Monitoramento;
import fiap.heinzChallenge.dao.models.MonitoramentoDAO;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OracleMonitoramentoDAO implements MonitoramentoDAO {

  private Connection connection;

  public OracleMonitoramentoDAO() {
    this.connection = ConnectionManager.obterConexao();
  }

  @Override
  public void cadastrar(Monitoramento monitoramento) {
    String sql =
      "INSERT INTO T_MONITORAMENTO (cod_monitoramento, nm_tipo, ds_descricao,dt_data, vl_valor,UNIDADE_DE_MEDIDA,T_LOTE_COD_LOTE,T_LOTE_T_DISTRIBUICAO_COD_DISTRIBUICAO) VALUES (?, ?, ?, ? ,? , ?, ?, ?)";

    try (PreparedStatement stmt = connection.prepareStatement(sql)) {
      stmt.setString(1, monitoramento.getCodMonitoramento());
      stmt.setString(2, monitoramento.getTipo());
      stmt.setString(3, monitoramento.getDescricao());
      stmt.setDate(4, monitoramento.getData());
      stmt.setDouble(5, monitoramento.getValor());
      stmt.setString(6, monitoramento.getUnidadeMedida());
      stmt.setString(7, monitoramento.getCodLote());
      stmt.setInt(8, monitoramento.getCodDistribuicao());
      
      stmt.executeUpdate();
    } catch (SQLException e) {
      throw new RuntimeException(e);
    }
  }

  @Override
  public List<Monitoramento> listar() {
    System.out.println("Listando monitoramentos do banco de dados Oracle");
    return null;
  }

  @Override
  public void atualizar(Monitoramento monitoramento) {
    System.out.println(
      "Monitoramento atualizado no banco de dados Oracle: " + monitoramento
    );
  }

  @Override
  public void remover(String codMonitoramento) {
    System.out.println(
      "Monitoramento removido do banco de dados Oracle. Código do Monitoramento: " +
      codMonitoramento
    );
  }

  @Override
  public Monitoramento buscarPorId(String codMonitoramento) {
    System.out.println(
      "Buscando monitoramento no banco de dados Oracle. Código do Monitoramento: " +
      codMonitoramento
    );
    return null;
  }
}
