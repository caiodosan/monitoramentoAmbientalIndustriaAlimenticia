package fiap.heinzChallenge.dao;

import fiap.heinzChallenge.ConnectionManager;
import fiap.heinzChallenge.Producao;
import fiap.heinzChallenge.dao.models.ProducaoDAO;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OracleProducaoDAO implements ProducaoDAO {

  private Connection connection;

  public OracleProducaoDAO() {
    this.connection = ConnectionManager.obterConexao();
  }

  @Override
  public void cadastrar(Producao producao) {
    String sql =
      "INSERT INTO T_PRODUCAO (cod_producao, dt_inicio, dt_fim, T_LOTE_COD_LOTE, T_LOTE_T_DISTRIBUICAO_COD_DISTRIBUICAO) VALUES (?, ?, ?, ?, ?)";

    try (PreparedStatement stmt = connection.prepareStatement(sql)) {
      stmt.setString(1, producao.getCodProducao());
      stmt.setTimestamp(2, producao.getDtInicio());
      stmt.setTimestamp(3, producao.getDtFim());
      stmt.setString(4, producao.getCodLote());
      stmt.setInt(5, producao.getCodDistribuicao());
      stmt.executeUpdate();
    } catch (SQLException e) {
      throw new RuntimeException(e);
    }
  }

  @Override
  public List<Producao> listar() {
    System.out.println("Listando produções do banco de dados Oracle");
    return null;
  }

  @Override
  public void atualizar(Producao producao) {
    System.out.println(
      "Produção atualizada no banco de dados Oracle: " + producao
    );
  }

  @Override
  public void remover(String codProducao) {
    System.out.println(
      "Produção removida do banco de dados Oracle. Código da Produção: " +
      codProducao
    );
  }

  @Override
  public Producao buscarPorId(String codProducao) {
    System.out.println(
      "Buscando produção no banco de dados Oracle. Código da Produção: " +
      codProducao
    );
    return null;
  }
}
