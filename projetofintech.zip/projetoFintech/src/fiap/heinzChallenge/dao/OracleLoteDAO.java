package fiap.heinzChallenge.dao;

import fiap.heinzChallenge.ConnectionManager;
import fiap.heinzChallenge.Lote;
import fiap.heinzChallenge.dao.models.LoteDAO;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OracleLoteDAO implements LoteDAO {

  private Connection connection;

  public OracleLoteDAO() {
    this.connection = ConnectionManager.obterConexao();
  }

  @Override
  public void cadastrar(Lote lote) {
    String sql =
      "INSERT INTO T_LOTE (cod_lote, dt_fabricacao, dt_validade, peso_lote, T_DISTRIBUICAO_COD_DISTRIBUICAO) VALUES (?, ?, ?, ?, ?)";

    try (PreparedStatement stmt = connection.prepareStatement(sql)) {
      stmt.setString(1, lote.getCodLote());
      stmt.setDate(2, lote.getDataFabricacao());
      stmt.setDate(3, lote.getDataValidade());
      stmt.setDouble(4, lote.getPesoLote());
      stmt.setInt(5, lote.getCodDistribuicao());
      stmt.executeUpdate();
    } catch (SQLException e) {
      throw new RuntimeException(e);
    }
  }

  @Override
  public List<Lote> listar() {
    System.out.println("Listando lotes do banco de dados Oracle");
    return null;
  }

  @Override
  public void atualizar(Lote lote) {
    System.out.println("Lote atualizado no banco de dados Oracle: " + lote);
  }



@Override
public void remover(String codLote, int codDistribuicao) {
	// TODO Auto-generated method stub
	
}

@Override
public Lote buscarPorId(String codLote, int codDistribuicao) {
	// TODO Auto-generated method stub
	return null;
}
}
