package fiap.heinzChallenge.dao;

import fiap.heinzChallenge.ConnectionManager;
import fiap.heinzChallenge.Distribuicao;
import fiap.heinzChallenge.dao.models.DistribuicaoDAO;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OracleDistribuicaoDAO implements DistribuicaoDAO {

  private Connection connection;

  public OracleDistribuicaoDAO() {
    this.connection = ConnectionManager.obterConexao();
  }

  @Override
  public void cadastrar(Distribuicao distribuicao) {
    String sql =
      "INSERT INTO T_DISTRIBUICAO (cod_distribuicao, capacidade_maxima, quantidade_transportada, dt_data) VALUES (?, ?, ?, ?)";

    try (PreparedStatement stmt = connection.prepareStatement(sql)) {
      stmt.setInt(1, distribuicao.getCodDistribuicao());
      stmt.setInt(2, distribuicao.getCapacidadeMaxima());
      stmt.setInt(3, distribuicao.getQuantidadeTransportada());
      stmt.setDate(4, distribuicao.getData());
      stmt.executeUpdate();
    } catch (SQLException e) {
      throw new RuntimeException(e);
    }
  }

  @Override
  public List<Distribuicao> listar() {
    System.out.println("Listando distribuições do banco de dados Oracle");
    return null;
  }

  @Override
  public void atualizar(Distribuicao distribuicao) {
    System.out.println(
      "Distribuição atualizada no banco de dados Oracle: " + distribuicao
    );
  }

  @Override
  public void remover(int codDistribuicao) {
    System.out.println(
      "Distribuição removida do banco de dados Oracle. Código da Distribuição: " +
      codDistribuicao
    );
  }

@Override
public Distribuicao buscarPorId(int codigoBusca) {
	// TODO Auto-generated method stub
	return null;
}

  
  
}
