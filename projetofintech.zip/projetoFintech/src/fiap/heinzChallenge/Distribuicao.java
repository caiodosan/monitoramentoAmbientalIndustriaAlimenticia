package fiap.heinzChallenge;

import java.sql.Date;

public class Distribuicao {

  private int codDistribuicao;
  private int capacidadeMaxima;
  private int quantidadeTransportada;
  private Date data;

  public Distribuicao(
    int codDistribuicao,
    int capacidadeMaxima,
    int quantidadeTransportada,
    Date data
  ) {
    this.codDistribuicao = codDistribuicao;
    this.capacidadeMaxima = capacidadeMaxima;
    this.quantidadeTransportada = quantidadeTransportada;
    this.data = data;
  }

  public int getCodDistribuicao() {
    return codDistribuicao;
  }

  public int getCapacidadeMaxima() {
    return capacidadeMaxima;
  }

  public void setCapacidadeMaxima(int capacidadeMaxima) {
    this.capacidadeMaxima = capacidadeMaxima;
  }

  public int getQuantidadeTransportada() {
    return quantidadeTransportada;
  }

  public void setQuantidadeTransportada(int quantidadeTransportada) {
    this.quantidadeTransportada = quantidadeTransportada;
  }

  public Date getData() {
    return data;
  }

  public void setData(Date data) {
    this.data = data;
  }
}
